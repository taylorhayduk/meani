angular.module('app.controllers', [])
  
.controller('browseCtrl', function($scope) {

})
   
.controller('wishListCtrl', function($scope) {

})
   
.controller('friendsCtrl', function($scope) {

})
      
.controller('loginCtrl', function($scope) {

})
 